from __future__ import division
import cv2
import numpy as np
import os
import ipdb
import math
from ipdb import launch_ipdb_on_exception


#########################
# Histogram classes
#########################

class Histogram:

    def __init__(self, histResolution, scaleDisplay, mode):
        self.mode = mode
        if mode == "LAB":
            self.histResolution = histResolution
            self.scaleDisplay = scaleDisplay
            self.histSize = [histResolution, histResolution]
            self.Ranges = [0, 255, 0, 255]
            self.Channels = [1, 2]
            self.Hist = np.zeros((histResolution, histResolution))
        elif mode == "RGB":
            self.histResolution = histResolution
            self.scaleDisplay = scaleDisplay
            self.histSize = [histResolution, histResolution]
            self.Ranges = [0, 255, 0, 255]
            self.Channels = [0, 1]
            self.Hist = np.zeros((histResolution, histResolution))
        elif mode == "HSV":
            self.histResolution = histResolution
            self.scaleDisplay = scaleDisplay
            self.histSize = [histResolution, histResolution]
            self.Ranges = [0, 179, 0, 255]
            self.Channels = [0, 1]
            self.Hist = np.zeros((histResolution, histResolution))

    def addImageToHist(self, image, mask):
        if self.mode == "LAB":
            self.Hist = cv2.calcHist([cv2.cvtColor(image, cv2.COLOR_BGR2LAB)], self.Channels, mask, self.histSize, self.Ranges, self.Hist, True)
        elif self.mode == "RGB":
            self.Hist = cv2.calcHist([cv2.cvtColor(image, cv2.COLOR_BGR2RGB)], self.Channels, mask, self.histSize, self.Ranges, self.Hist, True)
        elif self.mode == "HSV":
            self.Hist = cv2.calcHist([cv2.cvtColor(image, cv2.COLOR_BGR2HSV)], self.Channels, mask, self.histSize, self.Ranges, self.Hist, True)

    def getDiplayHist(self):
        maxHist = self.Hist.argmax()

        displayHist = np.zeros((self.histResolution * self.scaleDisplay, self.histResolution * self.scaleDisplay))
        for a in range(0, 32):
            for b in range(0, 32):
                cv2.rectangle(
                    displayHist,
                    (a*self.scaleDisplay, b*self.scaleDisplay),
                    ((a + 1)*self.scaleDisplay - 1, (b + 1)*self.scaleDisplay - 1),
                    self.Hist.item(a, b)/maxHist,
                    cv2.cv.CV_FILLED
                )
        return displayHist

###############################
#  UTILS
###############################

def generateMask(image):
    antimask = np.zeros((image.shape[0], image.shape[1], 1), np.uint8)
    mask = np.zeros((image.shape[0], image.shape[1], 1), np.uint8)

    for x in range(0, image.shape[0]):
        for y in range(0, image.shape[1]):
            if math.sqrt(image.item(x, y, 0)**2 + image.item(x, y, 1)**2 + image.item(x, y, 2)**2) > math.sqrt(3*250**2):
                mask.itemset((x, y, 0), 255)
                antimask.itemset((x, y, 0), 0)
            else:
                mask.itemset((x, y, 0), 0)
                antimask.itemset((x, y, 0), 255)
    return mask, antimask


###############################
#  MAIN
###############################

with launch_ipdb_on_exception():
    #
    # First, we scan the dirs to find the test images
    #

    files = []
    dirRawPath = './Raw/'
    dirFacesPath = './Faces/'

    for dirname, dirnames, filenames in os.walk(dirRawPath):
        for filename in filenames:
            files.append(filename.strip())


    #
    # We build the histogramms for both kind of images
    #
    histRange = 64
    scale = 5
    labHistPeau = Histogram(histRange, scale, "LAB")
    rgbHistPeau = Histogram(histRange, scale, "RGB")
    hsvHistPeau = Histogram(histRange, scale, "HSV")

    labHist = Histogram(histRange, scale, "LAB")
    rgbHist = Histogram(histRange, scale, "RGB")
    hsvHist = Histogram(histRange, scale, "HSV")

    files = files[:5]
    for f in files:
        print "Adding file : %s " % dirFacesPath + f.split('.')[0] + '_R.jpg'
        print "Adding file : %s " % dirRawPath + f

        rawImage = cv2.imread(dirRawPath + f)
        faceImage = cv2.imread(dirFacesPath + f.split('.')[0] + '_R.jpg')

        mask, antimask = generateMask(faceImage)

        
        labHist.addImageToHist(
            rawImage,
            antimask
            )
        labHistPeau.addImageToHist(
            faceImage,
            mask
            )

        rgbHist.addImageToHist(
            rawImage,
            antimask
            )
        rgbHistPeau.addImageToHist(
            faceImage,
            mask
            )

        hsvHist.addImageToHist(
            rawImage,
            antimask
            )
        hsvHistPeau.addImageToHist(
            faceImage,
            mask
            )

    cv2.namedWindow("Lab Histogram")
    cv2.imshow("Lab Histogram", labHist.getDiplayHist())
    cv2.namedWindow("RGB Histogram")
    cv2.imshow("RGB Histogram", rgbHist.getDiplayHist())
    cv2.namedWindow("HSV Histogram")
    cv2.imshow("HSV Histogram", hsvHist.getDiplayHist())


    cv2.namedWindow("Lab Histogram Peau")
    cv2.imshow("Lab Histogram Peau", labHistPeau.getDiplayHist())
    cv2.namedWindow("RGB Histogram Peau")
    cv2.imshow("RGB Histogram Peau", rgbHistPeau.getDiplayHist())
    cv2.namedWindow("HSV Histogram Peau")
    cv2.imshow("HSV Histogram Peau", hsvHistPeau.getDiplayHist())

    cv2.waitKey(0)